package org.uima.jCasType;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

public class DateAnnot extends DateTimeAnnot {

  public final static int typeIndexID = JCasRegistry.register(DateAnnot.class);

  public final static int type = typeIndexID;

  public int getTypeIndexID() {return typeIndexID;}

  protected DateAnnot() {/* intentionally empty block */}

  public DateAnnot(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  public DateAnnot(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  public DateAnnot(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  private void readObject() {
  }

}
