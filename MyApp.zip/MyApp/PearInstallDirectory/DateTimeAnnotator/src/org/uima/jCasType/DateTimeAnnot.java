package org.uima.jCasType;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;
import org.apache.uima.jcas.tcas.Annotation;

public class DateTimeAnnot extends Annotation {

  public final static int typeIndexID = JCasRegistry.register(DateTimeAnnot.class);

  public final static int type = typeIndexID;

  public int getTypeIndexID() {return typeIndexID;}

  protected DateTimeAnnot() {/* intentionally empty block */}

  public DateTimeAnnot(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }

  public DateTimeAnnot(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  public DateTimeAnnot(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }

  private void readObject() {
  }

  // *--------------*
  // * Feature: shortDateString

  /**
   * getter for shortDateString - gets
   * 
   * @generated
   */
  public String getShortDateString() {
    if (DateTimeAnnot_Type.featOkTst && ((DateTimeAnnot_Type)jcasType).casFeat_shortDateString == null)
      jcasType.jcas.throwFeatMissing("shortDateString", "org.uima.jCasType.DateTimeAnnot");
    return jcasType.ll_cas.ll_getStringValue(addr, ((DateTimeAnnot_Type)jcasType).casFeatCode_shortDateString);}
    
  /**
   * setter for shortDateString - sets
   * 
   * @generated
   */
  public void setShortDateString(String v) {
    if (DateTimeAnnot_Type.featOkTst && ((DateTimeAnnot_Type)jcasType).casFeat_shortDateString == null)
      jcasType.jcas.throwFeatMissing("shortDateString", "org.uima.jCasType.DateTimeAnnot");
    jcasType.ll_cas.ll_setStringValue(addr, ((DateTimeAnnot_Type)jcasType).casFeatCode_shortDateString, v);}    
  }
