/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.uima.annotators;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.jcas.JCas;
import org.uima.jCasType.RoomNumber;

/**
 * Example annotator that detects room numbers using Java 1.4 regular expressions.
 */
public class RoomNumberAnnotator extends JCasAnnotator_ImplBase {
	  
	// create regular expression pattern for Yorktown room number
	  private Pattern mYorktownPattern = Pattern.compile("\\b[0-4]\\d-[0-2]\\d\\d\\b");

	  // create regular expression pattern for Hawthorne room number
	  private Pattern mHawthornePattern = Pattern.compile("\\b[G1-4][NS]-[A-Z]\\d\\d\\b");
	
	  /**
	   * Questo metodo viene chiamato una volta per ogni documento che deve
	   * essere analizzato. Il JCas passato in ingresso permette di analizzare 
	   * il documento.
	   * @see JCasAnnotator_ImplBase#process(JCas)
	   */
	  public void process(JCas aJCas) {
		  
		  // The JCas object is the data object inside UIMA where all the 
		  // information is stored. It contains all annotations created by 
		  // previous annotators, and the document text to be analyzed.
		  
		  // get document text from JCas
		  String docText = aJCas.getDocumentText();
		    
		  // search for Yorktown room numbers
		  Matcher matcher = mYorktownPattern.matcher(docText);
		  int pos = 0;
		  while (matcher.find(pos)) {
			  // match found - create the match as annotation in 
			  // the JCas with some additional meta information
			  RoomNumber annotation = new RoomNumber(aJCas);
			  annotation.setBegin(matcher.start());
			  annotation.setEnd(matcher.end());
			  annotation.setBuilding("Yorktown");
			  annotation.addToIndexes();
			  pos = matcher.end();
		  }
	  
		  // search for Hawthorne room numbers
		  matcher = mHawthornePattern.matcher(docText);
		  pos = 0;
		  while (matcher.find(pos)) {
			  // match found - create the match as annotation in 
			  // the JCas with some additional meta information
			  RoomNumber annotation = new RoomNumber(aJCas);
			  annotation.setBegin(matcher.start());
			  annotation.setEnd(matcher.end());
			  annotation.setBuilding("Hawthorne");
			  annotation.addToIndexes();
			  pos = matcher.end();
		  }
	  }

}
